# Week 2 - Practice Answers

These are procedures and explanations. Live execution remains pending.

## 1. Launch and connect to an EC2 Ubuntu instance

Choose an Ubuntu Server AMI, an instance size, a key pair, and a public subnet with an Internet Gateway route. Assign a public IP. Allow inbound SSH (TCP 22) only from your public IP `/32`. Launch the instance and wait for its status checks. Connect using the Ubuntu AMI's default username:

```bash
ssh -i "your-key.pem" ubuntu@YOUR-EC2-PUBLIC-IP
hostname
whoami
```

On Linux/macOS, run `chmod 400 your-key.pem` first. On Windows, ensure the private key is accessible only to your Windows account if OpenSSH rejects its permissions. Never upload the private key to S3 or include it in a submission. The prepared CloudFormation template automates the launch configuration.

## 2. Install and configure a web server on EC2

Connect over SSH, then run:

```bash
sudo apt-get update
sudo apt-get install -y apache2
sudo systemctl enable --now apache2
sudo systemctl status apache2 --no-pager
```

From a local terminal in the submission directory, upload the site:

```bash
scp -i "your-key.pem" -r site ubuntu@YOUR-EC2-PUBLIC-IP:~/
```

Back in the SSH session:

```bash
sudo cp ~/site/* /var/www/html/
sudo chmod 644 /var/www/html/*
curl -I http://localhost
```

Allow TCP port 80 from `0.0.0.0/0` in the instance security group and visit `http://YOUR-EC2-PUBLIC-IP`. The supplied template's user-data script performs installation and file placement automatically, so these manual installation steps are an alternative, not required a second time.

## 3. Create an S3 bucket and upload files

In S3, choose Create bucket, select a region, and use a globally unique general purpose bucket name. Keep Object Ownership set to Bucket owner enforced. Upload `index.html`, `styles.css`, and `error.html` at the bucket root.

With configured AWS CLI credentials, an alternative is:

```bash
aws s3 mb s3://YOUR-UNIQUE-BUCKET --region YOUR-REGION
aws s3 sync ./site s3://YOUR-UNIQUE-BUCKET --region YOUR-REGION
aws s3 ls s3://YOUR-UNIQUE-BUCKET
```

Creating and uploading alone does not make a bucket publicly readable. If using the supplied CloudFormation stack, reuse its bucket instead of creating another.

## 4. Host a static website using S3

Open the bucket's Properties tab, enable Static website hosting, select Host a static website, and set the index document to `index.html` and the error document to `error.html`. Apply the access settings in question 5, then open the exact website endpoint shown by S3. Use the website endpoint rather than an ordinary S3 object URL.

CLI equivalent for enabling hosting:

```bash
aws s3 website s3://YOUR-UNIQUE-BUCKET --index-document index.html --error-document error.html
```

S3 serves static files; it does not execute PHP, Python, or other server-side application code. This HTML/CSS portfolio requires no backend.

## 5. Configure an S3 bucket policy for public access

For the dedicated website bucket, retain BlockPublicAcls and IgnorePublicAcls as true; set BlockPublicPolicy and RestrictPublicBuckets to false. Account and organization settings must also permit the policy. Add this policy under Permissions > Bucket policy, replacing YOUR-UNIQUE-BUCKET:

```json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Sid": "PublicReadWebsite",
    "Effect": "Allow",
    "Principal": "*",
    "Action": "s3:GetObject",
    "Resource": "arn:aws:s3:::YOUR-UNIQUE-BUCKET/*"
  }]
}
```

This permits anonymous reads of objects in that bucket. It does not grant uploads, deletions, or bucket listing. Keep only public website files in this bucket. The CloudFormation template supplies the equivalent policy using the generated bucket ARN.

## Additional topic notes

- **EC2:** configurable virtual machines; you manage the operating system and installed web server.
- **EBS:** block storage attached to EC2. The template uses an encrypted gp3 root volume that is deleted when its instance is terminated.
- **Snapshots:** point-in-time EBS backups. For consistent application data, quiesce writes before creating a snapshot; wait for completion before relying on it. Snapshots are separately retained and billed until deleted.
- **S3:** object storage accessed through APIs; website hosting serves static objects without an always-running VM.
- **CloudFront:** optional CDN for caching and HTTPS delivery. Not provisioned in this files-only package.
- **AWS CLI:** command-line access to AWS APIs; authenticate before running commands and keep credentials outside project files.

See README.md for deployment, evidence collection, cleanup, and official references.

"""Run with Python 3 after editing site files to rebuild the EC2 user data."""
import base64
import json
from pathlib import Path

root = Path(__file__).resolve().parent
ref = lambda name: {'Ref': name}
get = lambda name, attr: {'Fn::GetAtt': [name, attr]}
script = '#!/bin/bash\nset -euo pipefail\nexport DEBIAN_FRONTEND=noninteractive\napt-get update\napt-get install -y apache2\n'
for file in sorted((root.parent / 'site').iterdir()):
    if file.is_file():
        data = base64.b64encode(file.read_bytes()).decode()
        script += f"printf '%s' '{data}' | base64 --decode > /var/www/html/{file.name}\n"
script += 'chmod 644 /var/www/html/*\nsystemctl enable --now apache2\n'
(root / 'ec2-user-data.sh').write_text(script, encoding='utf-8', newline='\n')
template = {
 'AWSTemplateFormatVersion': '2010-09-09',
 'Description': 'Week 2: Ubuntu Apache web server and S3 static portfolio website',
 'Parameters': {
  'VpcId': {'Type': 'AWS::EC2::VPC::Id', 'Description': 'VPC containing the selected public subnet'},
  'SubnetId': {'Type': 'AWS::EC2::Subnet::Id', 'Description': 'Public subnet in VpcId with a route to an Internet Gateway'},
  'KeyName': {'Type': 'AWS::EC2::KeyPair::KeyName', 'Description': 'Existing key pair whose private key you possess'},
  'SSHLocation': {'Type': 'String', 'AllowedPattern': r'(\d{1,3}\.){3}\d{1,3}/32', 'Description': 'Your current public IPv4 address followed by /32'},
  'LatestAmiId': {'Type': 'AWS::SSM::Parameter::Value<AWS::EC2::Image::Id>', 'Default': '/aws/service/canonical/ubuntu/server/noble/stable/current/amd64/hvm/ebs-gp3/ami-id'}
 },
 'Resources': {
  'WebSecurityGroup': {'Type': 'AWS::EC2::SecurityGroup', 'Properties': {
   'GroupDescription': 'Public HTTP and SSH from the student IP only', 'VpcId': ref('VpcId'),
   'SecurityGroupIngress': [
    {'IpProtocol': 'tcp', 'FromPort': 80, 'ToPort': 80, 'CidrIp': '0.0.0.0/0'},
    {'IpProtocol': 'tcp', 'FromPort': 22, 'ToPort': 22, 'CidrIp': ref('SSHLocation')}
   ]}},
  'WebServer': {'Type': 'AWS::EC2::Instance', 'Properties': {
   'ImageId': ref('LatestAmiId'), 'InstanceType': 't3.micro', 'KeyName': ref('KeyName'),
   'MetadataOptions': {'HttpTokens': 'required'},
   'NetworkInterfaces': [{'AssociatePublicIpAddress': True, 'DeviceIndex': '0', 'SubnetId': ref('SubnetId'), 'GroupSet': [ref('WebSecurityGroup')]}],
   'BlockDeviceMappings': [{'DeviceName': '/dev/sda1', 'Ebs': {'VolumeSize': 8, 'VolumeType': 'gp3', 'Encrypted': True, 'DeleteOnTermination': True}}],
   'UserData': {'Fn::Base64': script}, 'Tags': [{'Key': 'Name', 'Value': 'week2-portfolio'}]
  }},
  'WebsiteBucket': {'Type': 'AWS::S3::Bucket', 'Properties': {
   'WebsiteConfiguration': {'IndexDocument': 'index.html', 'ErrorDocument': 'error.html'},
   'OwnershipControls': {'Rules': [{'ObjectOwnership': 'BucketOwnerEnforced'}]},
   'PublicAccessBlockConfiguration': {'BlockPublicAcls': True, 'IgnorePublicAcls': True, 'BlockPublicPolicy': False, 'RestrictPublicBuckets': False}
  }},
  'WebsitePolicy': {'Type': 'AWS::S3::BucketPolicy', 'Properties': {
   'Bucket': ref('WebsiteBucket'),
   'PolicyDocument': {'Version': '2012-10-17', 'Statement': [{'Sid': 'PublicReadWebsite', 'Effect': 'Allow', 'Principal': '*', 'Action': 's3:GetObject', 'Resource': {'Fn::Sub': '${WebsiteBucket.Arn}/*'}}]}
  }}
 },
 'Outputs': {
  'BucketName': {'Value': ref('WebsiteBucket')},
  'S3WebsiteURL': {'Value': get('WebsiteBucket', 'WebsiteURL')},
  'EC2WebsiteURL': {'Value': {'Fn::Sub': 'http://${WebServer.PublicIp}'}},
  'InstanceId': {'Value': ref('WebServer')},
  'SSHCommand': {'Value': {'Fn::Sub': 'ssh -i YOUR-KEY.pem ubuntu@${WebServer.PublicIp}'}}
 }
}
(root / 'cloudformation.json').write_text(json.dumps(template, indent=2) + '\n', encoding='utf-8')
print('Generated cloudformation.json and ec2-user-data.sh')

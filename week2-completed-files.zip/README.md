# Week 2 - AWS Compute & Storage

Prepared for the two assignments, mini project, and five practice questions in the supplied PDFs.

**Status:** Website and deployment files prepared. No AWS resources have been created, no SSH connection has been made, and no live deployment results or screenshots are claimed. The requested scope is files only.

## Files

- `site/index.html`: responsive student portfolio with About, Projects, and Skills sections.
- `site/styles.css`: desktop and mobile styling; no libraries or build tools required.
- `site/error.html`: custom error page.
- `aws/cloudformation.json`: deploys an Ubuntu 24.04 EC2 server with Apache and an S3 website bucket with a public read policy.
- `aws/ec2-user-data.sh`: installs Apache and writes the included website files to the web root.
- `aws/build_template.py`: regenerates the template and bootstrap script after website edits.
- `PRACTICE-ANSWERS.md`: answers and commands for all five practice questions.

Open `site/index.html` in a browser to preview. The portfolio uses a neutral student identity because no student name or contact details were supplied. Add your name if required, then run `python aws/build_template.py` to update the embedded EC2 copy.

## Assignment 1: Launch and configure EC2

### Fast path using the prepared template

1. Sign in to AWS and select a region. Create or select an EC2 key pair and keep its private key locally.
2. Select a VPC and a **public subnet in that VPC**. The subnet route table must route `0.0.0.0/0` to an attached Internet Gateway. A default VPC public subnet is suitable when available.
3. In CloudFormation, choose Create stack > With new resources > Upload a template file. Upload `aws/cloudformation.json` and name the stack `week2-portfolio`.
4. Supply VpcId, SubnetId, KeyName, and SSHLocation (your current public IPv4 address followed by `/32`). Leave the Ubuntu AMI parameter unchanged.
5. Review and create the stack. This creates chargeable AWS resources; free-tier eligibility varies by account. The template uses a t3.micro instance, an encrypted 8 GiB gp3 disk, and a public IPv4 address.
6. Wait for stack completion. Apache installation runs asynchronously through cloud-init; stack completion alone does not confirm the website is ready.
7. Read the Outputs tab. Open EC2WebsiteURL over HTTP after a few minutes. Use SSHCommand with the actual private-key path to connect as `ubuntu`.

On Ubuntu, verify:

```bash
sudo cloud-init status --wait
sudo systemctl status apache2 --no-pager
curl -I http://localhost
ls -l /var/www/html
```

Expected results (not yet observed): Apache active, HTTP 200 for the home page, and the three portfolio files in `/var/www/html`.

If provisioning fails, inspect `sudo tail -100 /var/log/cloud-init-output.log`. If a browser times out, check the subnet Internet Gateway route, public IPv4 address, and security group HTTP rule. SSH is permitted only from SSHLocation; update it if your public IP changes.

## Assignment 2 and mini project: S3 static portfolio

The template creates a uniquely named bucket, enables website hosting, sets index/error documents, and attaches an anonymous **GetObject-only** policy. It does not upload the files automatically.

1. In the CloudFormation Outputs tab, copy BucketName.
2. Open that bucket in S3, choose Upload, and upload the **three files inside `site/` directly into the bucket root**. Do not upload the parent folder or the assignment package.
3. Open S3WebsiteURL from the stack outputs. Confirm the design loads and the navigation links work.
4. Visit `/missing-page.html` to check the custom error page (HTTP 404 is expected).

Alternatively, after configuring AWS CLI credentials, run from this submission directory:

```powershell
aws sts get-caller-identity
aws s3 sync ./site s3://YOUR-BUCKET-NAME --region YOUR-REGION
```

Replace the two uppercase values with actual values. This uploads only the public website assets. No `--acl public-read` is needed because access is granted by the bucket policy and ACLs are disabled.

S3 account-level or organization-level Block Public Access can still reject the public policy. If it does, the stack may roll back. Review the account setting with the account owner; this template does not change account-wide controls. Use an account that permits this exercise. Bucket-level public ACL protection stays enabled; only policy-related blocks are disabled on this new website bucket.

S3 website endpoints support HTTP, not HTTPS. CloudFront is optional in the assignment and is omitted from this package. A future HTTPS deployment can use CloudFront and a private S3 REST origin with Origin Access Control; that is a different access model from this public S3 website exercise.

## Evidence to collect after deployment

| Requirement | Evidence needed | Current status |
|---|---|---|
| Ubuntu EC2 launch | Instance page showing running state and Ubuntu AMI | Pending |
| SSH connection | Terminal showing `ubuntu` and `hostname` | Pending |
| Apache configuration | `systemctl status apache2` and HTTP 200 response | Pending |
| EC2 website | Browser showing portfolio at instance HTTP URL | Pending |
| S3 upload | Bucket object list with HTML and CSS files | Pending |
| Public permissions | Bucket policy and relevant Block Public Access settings | Pending |
| S3 website | Browser showing portfolio at S3 website URL | Pending |

Do not submit the pending steps as completed practical work. Add your actual URLs, screenshots, name, and student ID when the live exercise is done.

## Cleanup after assessment

Empty only the dedicated portfolio bucket, then delete the `week2-portfolio` CloudFormation stack. A nonempty bucket prevents stack deletion. The stack removes its EC2 instance, attached root disk, security group, bucket policy, and empty bucket. It leaves the pre-existing VPC, subnet, and key pair alone. Save any needed server files before deletion. Stopping EC2 alone does not remove all storage costs.

## References

- [AWS: S3 website tutorial](https://docs.aws.amazon.com/AmazonS3/latest/userguide/HostingWebsiteOnS3Setup.html)
- [AWS: Block Public Access](https://docs.aws.amazon.com/AmazonS3/latest/userguide/access-control-block-public-access.html)
- [Canonical: Ubuntu CloudFormation AMI parameters](https://ubuntu.com/aws/docs/aws-how-to/instances/build-cloudformation-templates/)
- [AWS: EC2 CloudFormation reference](https://docs.aws.amazon.com/AWSCloudFormation/latest/TemplateReference/aws-resource-ec2-instance.html)
